﻿using UserCRUDApllication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserCRUDApllication.Repositories
{
    public interface IProductRepository
    {
        void Add(ProductService product);
        ProductService GetById(int id);
        IEnumerable<ProductService> GetAll();
        void Update(ProductService product);
        void Remove(int id);
    }
}
