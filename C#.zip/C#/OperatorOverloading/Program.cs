﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design.Serialization;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static OperatorOverloading.Program;

namespace OperatorOverloading
{
    public class Program
    {
        static void Main(string[] args)
        {
            data d1 = new data(5);   // d1.number = 5
            data d2 = new data(10);  // d2.number = 10
            data d3 = d1 + d2;       // d3.number = 15
            d3.display();


        }
        public class data
        {
            public int number;         //field;

            public data()               //constructor overloading;
            {
                number = 0;
            }
            public data(int n)          //method overloading;
            {
                number = n;
            }
            public static data operator +(data d1, data d2)
            {
                data d3 = new data();
                d3.number = d1.number + d2.number;
                return d3;
            }
            public void display()
            {
                Console.WriteLine("{0}", number);
            }
        }

    }
}
