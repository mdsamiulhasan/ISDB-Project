﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Object_Approach
{
    public class TwoWheeler:Vehicle
    {
        public int MaximumPoweBPH { get; set; }
        public int MaximumTorqueNM { get; set; }
        public int MileageKMPL { get; set; }
        public string Cooling { get; set; }

        
        public virtual void Start()      //virtual method
        {
            Console.WriteLine("StartENgine");

        }
        public virtual void RearBrake()
        {
            Console.WriteLine("RearBrake");

        }
        public virtual void ExteriorDesign()
        {
            Console.WriteLine("ExteriorDesing");

        }
    }
}
