﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Object_Approach
{
    internal class Program
    {
        static void Main(string[] args)          //main class
        {
            // Output
            Console.WriteLine("=================Car design===================");
            Console.WriteLine("\t");
            Car C = new Car("BMW-01",10,5,"Red");      ////object Declaration
            Console.WriteLine($"ModelNo: : {C.ModelNo}");
            Console.WriteLine($"NumberOfSeat: {C.NumberOfSet}");
            Console.WriteLine($"NumberOfDoor: {C.NumberOfDoor}");
            Console.WriteLine($"InteriorDesign : {C.InteriorDesign}");
            Console.WriteLine("\t");
            Console.WriteLine("=================MotorCycle design==================="); 
            Console.WriteLine("\t");
            //Motorcycle Design
             
            MotorCycle M = new MotorCycle("Hero Honda s0",120,2010,4,150,128,VehicleType.MotorCycle,170,"Cool");  //object Declaration
            //output
            Console.WriteLine($"ModelNo:{M.ModelNo}");
            Console.WriteLine($"MaximumPoweBPH:{M.MaximumPoweBPH}");
            Console.WriteLine($"YearMake:{M.YearMake}");
            Console.WriteLine($"NumberOfGear:{M.NumberOfGear}");
            Console.WriteLine($"MaximumTorqueNM:{M.MaximumTorqueNM}");
            Console.WriteLine($"MaximumPoweBPH:{M.MaximumPoweBPH}");
            Console.WriteLine($"Type:{M.Type}");
            Console.WriteLine($"MileageKMPL:{M.MileageKMPL}");
            Console.WriteLine($"Cooling:{M.Cooling}");
            M.ExteriorDesign();
            M.Start();
            M.RearBrake();
            M.ExteriorDesign();
            Console.ReadLine();
        }
    }
}
