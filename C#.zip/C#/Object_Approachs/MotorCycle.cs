﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Object_Approach
{
    public class MotorCycle:TwoWheeler     
    {
       public MotorCycle()   //default Constractor
        {

        }
        public MotorCycle(string ModelNo ,int MaximumPoweBPH, int YearMake, int NumberOfGear, int EngineCapacityCc ,int MaximumTorqueNM, VehicleType Type, int MileageKMPL, string Cooling)//Constructor overloading
        {
            this.MaximumPoweBPH = MaximumPoweBPH;
            this.MaximumTorqueNM = MaximumTorqueNM;
            this.MileageKMPL = MileageKMPL;
            this.Cooling = Cooling;
            this.ModelNo = ModelNo;
            this.MaximumPoweBPH = MaximumPoweBPH;
            this.YearMake = YearMake;
            this.NumberOfGear = NumberOfGear;
            this.EngineCapacityCc = EngineCapacityCc;
            this.MaximumTorqueNM = MaximumTorqueNM;
            this.Type = Type;

        }
        // **Method Overriding**: Start method from base class
        public override void Start()    {      
            Console.WriteLine("StartEngine");

        }
        // **Method Overriding**: RearBrake method from base class
        public override void RearBrake()
        {
            Console.WriteLine("RearBrake");

        }
        // **Method Overriding**: ExteriorDesign method from base class
        public override void ExteriorDesign()
        {
            Console.WriteLine("ExteriorDesing");

        }

    }
}
