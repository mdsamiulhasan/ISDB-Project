﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Object_Approach
{
    public class FourWheeler : Vehicle          //class  declaration with inheritence
    {
        public int NumberOfSet { get; set; }
        public int NumberOfDoor { get; set; }
        public string InteriorDesign { get; set; }

        //public string ModelNo { get; set; }
        //public int YearMake { get; set; }
        //public int NumberOfGear { get; set; }
        //public int EngineCapacityCc { get; set; }
        //public VehicleType Type { get; set; }
      

    }
}
