﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Object_Approach
{
     class Car:FourWheeler 
    {
      
        public Car(String ModelNo,int NumberOfSet, int NumberOfDoor, string InteriorDesign)
        {
            this
                .ModelNo = ModelNo;
            this.NumberOfSet = NumberOfSet;
            this.NumberOfDoor = NumberOfDoor;
            this.InteriorDesign = InteriorDesign;
        }
    }
}
