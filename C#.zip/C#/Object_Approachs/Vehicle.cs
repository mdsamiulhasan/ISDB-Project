﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Object_Approach
{
    public class Vehicle                   // use as base class
    {
        public string ModelNo { get; set; }
        public int YearMake { get; set; }
        public int NumberOfGear { get; set; }
        public int EngineCapacityCc { get; set; }
        public VehicleType Type{get; set;}
        //base class constructor

        //display the virtual method information
        //public virtual void Display()
        //{
        //    Console.WriteLine($"ModelNo:{ModelNo} \n YearMake:{YearMake} NumberOfGear:{NumberOfGear} EngineCapacityCc :{EngineCapacityCc} Type:{Type}");
        //}

    }
}
