﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Multitasking
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            //By using threads
            Thread T1 = new Thread(PrintNumbers);
            Thread T2 = new Thread(PrintAlphabet);
            T1.Start();
            T2.Start();
            T1.Join();
            T2.Join();
            //by using tasks
            Task t1 = new Task(() => PrintNumber());
            Task t2 = new Task(() => PrintAlphabets());
            Task.WaitAll(t1,t2);
            //by using async/await
            await Task.WhenAll(Numbers(), Alphabets());
        }
         static void PrintNumbers()
        {
            for (int i=1;i<=5;i++)
            {
                Console.WriteLine(i);
                Thread.Sleep(500);
            }
        }
        static void PrintAlphabet()
        {
            for (char c='a'; c<='e'; c++)
            {
                Console.WriteLine(c);
                Thread.Sleep(500);
            }
        }
        static void PrintNumber()
        {
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine(i);
                Thread.Sleep(500);
            }
        }
        static void PrintAlphabets()
        {
            for (char c = 'a'; c <= 'e'; c++)
            {
                Console.WriteLine(c);
                Thread.Sleep(500);
            }
        }

        static async Task Numbers()
        {
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine(i);
                await Task.Delay(300);
            }
        }
        static async Task Alphabets()
        {
            for (char c = 'a'; c <= 'e'; c++)
            {
                Console.WriteLine(c);
                Thread.Sleep(500);
                await Task.Delay(100);
            }
        }
    }
}
