﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_Object
{
    public class Program
    {
        static void Main(string[] args)
        {
            //output of the car       
            Console.WriteLine("==============Car Design================");
            Car c = new Car("BMW", 2020, 2, 4, 1200, VehicleType.Car,12);
            Console.WriteLine($"ModelNo: {c.ModelNo}");
            Console.WriteLine($"Yearmake: {c.YearMalke}");
            Console.WriteLine($"NumberOfseat: {c.NumberOfseat}");
            Console.WriteLine($"NumberOfGear: {c.NumberOfGear}");
            Console.WriteLine($"EngineCapacityCc: {c.EngineCapacityCc}");
            Console.WriteLine($"VehicleType Type: {c.Type}");
            Console.WriteLine($"NumberOfDoor: {c.NumberOfDoor}");
            c.Start();
            c.ExteriorDesign();
            c.RareBrake();
            c.FrontBrake();
            //output of the car  
            Console.WriteLine("=================motorcycle design");
            Car m = new Car("Hero Honda", 2020, 2, 4, 1200, VehicleType.Car, 12);
            Console.WriteLine($"ModelNo: {m.ModelNo}");
            Console.WriteLine($"Yearmake: {m.YearMalke}");
            Console.WriteLine($"NumberOfseat: {m.NumberOfseat}");
            Console.WriteLine($"NumberOfGear: {m.NumberOfGear}");
            Console.WriteLine($"EngineCapacityCc: {m.EngineCapacityCc}");
            Console.WriteLine($"VehicleType Type: {m.Type}");
            Console.WriteLine($"NumberOfDoor: {m.NumberOfDoor}");
            m.Start();
            m.ExteriorDesign();
            m.RareBrake();
            m.FrontBrake();
            Console.ReadLine();
        }
    }
}
