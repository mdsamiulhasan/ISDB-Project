﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_Object
{
    public class Fourwheeler:Vehicle,IFourWheeler
    {
       public string interiorDesign()
        {
            return "This is interorDesign";
        }
    }
}
