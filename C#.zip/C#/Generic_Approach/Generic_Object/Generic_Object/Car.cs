﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_Object
{
    public class Car : Twowheeler
    {
        public Car()      //constractor overlaoding
        {

        }
        public int NumberOfDoor { get; set; }
        public Car(string ModelNo, int YearMalke, int NumberOfseat, int NumberOfGear, int EngineCapacityCc, VehicleType Type, int NumberOfDoor)                      //method overloading
        {
            this.ModelNo = ModelNo;
            this.YearMalke = YearMalke;
            this.NumberOfseat = NumberOfseat;
            this.NumberOfGear = NumberOfGear;
            this.EngineCapacityCc = EngineCapacityCc;
            this.Type = Type;
            this.NumberOfDoor = NumberOfDoor;
        }
        public override void Start()
        {
            Console.WriteLine("Start ENGINE.....");
        }
        public override void RareBrake()
        {
            Console.WriteLine("RareBrake.....");
        }
        public override void FrontBrake()
        {
            Console.WriteLine("FrontBrake.....");
        }
    }
}
