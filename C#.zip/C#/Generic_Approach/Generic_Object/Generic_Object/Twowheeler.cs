﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Generic_Object
{
    public class Twowheeler:Vehicle,ITwhowheeler
    {
        public string ExteriorDesign()
        {
            return "This is ExteriorDesign";
        }
    }
}
