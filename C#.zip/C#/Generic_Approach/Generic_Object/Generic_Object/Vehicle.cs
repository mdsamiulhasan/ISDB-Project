﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_Object
{
    public class Vehicle
    {
        public string ModelNo { get; set; }
        public int YearMalke { get; set; }
        public int NumberOfseat { get; set; }
        public int NumberOfGear { get; set; }
        public int EngineCapacityCc { get; set; }
        public VehicleType Type { get; set; }
        public virtual void Start()
        {
            Console.WriteLine("Start ENGINE.....");
        }
        public virtual void RareBrake()
        {
            Console.WriteLine("RareBrake.....");
        }
        public virtual void FrontBrake()
        {
            Console.WriteLine("FrontBrake.....");
        }

    }
  
}
