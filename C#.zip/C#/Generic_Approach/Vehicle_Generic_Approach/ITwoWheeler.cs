﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle_Generic_Approach
{
    public interface ITwoWheeler<S>
    {
        string EnteriorDesign(S data);
    }
}
