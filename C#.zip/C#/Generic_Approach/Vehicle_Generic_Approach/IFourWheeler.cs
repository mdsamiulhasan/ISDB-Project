﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle_Generic_Approach
{
    public interface IFourWheeler<S>
    {
        string InteriorDesing<S>(S data) where S : Vehicle<S>;
    }
}
