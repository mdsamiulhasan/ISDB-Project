﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle_Generic_Approach
{
    public class Fourwheeler<S>:Vehicle<S>, IFourWheeler<S>
    {
        public string InteriorDesing<S>(S data)where S : Vehicle<S>
        {
            return "InteriorDesing";
        }
    }
}
