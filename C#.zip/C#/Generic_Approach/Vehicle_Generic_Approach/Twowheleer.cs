﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle_Generic_Approach
{
    public class Twowheleer<S>:Vehicle<S>,ITwoWheeler<S>
    {
        public string EnteriorDesign(S data) {
            return "EnteriorDesign";
        }
    }
}
