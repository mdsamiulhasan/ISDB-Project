﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle_Generic_Approach
{
    public class Vehicle<S>
    {
        public string ModelNo { get; set; }
        public int YearMake { get; set; }
        public int NumberOfSeat { get; set; }
        public int NumberOfGear { get; set; }
        public int MileageKmpl { get; set; }
        public int EngineCapacityCc { get; set; }
        public VehicleType type { get; set; }
        public virtual void Start()
        {
            Console.WriteLine("Start Engine");
        }
        public virtual void RearBreak()
        {
            Console.WriteLine("Rear Break");
        }
        public virtual void FrontBreak()
        {
            Console.WriteLine("Front Break");
        }
    }
}
