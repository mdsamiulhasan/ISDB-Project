﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle_Generic_Approach
{
    public sealed class MotorCycle<T> : Twowheleer<T>
    {
        public MotorCycle()
        { }
        public MotorCycle(string modelno, int yearmake, int numberofseat, int numberofgear, int milage, VehicleType type, int enginecapacitycc, int NumberOfDoor)
        {
            this.ModelNo = modelno;
            this.YearMake = yearmake;
            this.NumberOfSeat = numberofseat;
            this.NumberOfGear = numberofgear;
            this.MileageKmpl = milage;
            this.type = type;
            this.EngineCapacityCc = enginecapacitycc;
            this.NumberOfDoor = NumberOfDoor;
        }
        public int NumberOfDoor { get; set; }
        public override void Start()
        {
            Console.WriteLine("MotorCycle Start Engine");
        }
        public override void RearBreak()
        {
            Console.WriteLine("Motorcycle RearBreak");
        }
        public override void FrontBreak()
        {
            Console.WriteLine("MotorCycle FrontBreak");
        }
    }

}



