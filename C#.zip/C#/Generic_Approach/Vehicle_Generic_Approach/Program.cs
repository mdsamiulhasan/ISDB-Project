﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management.Instrumentation;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle_Generic_Approach
{
    public class Program
    {
        static void Main(string[] args)
        {
            //car design
            Console.WriteLine("===========Car Design===================");
            Car<string> car = new Car<string>("BMW-S420",2020,56,4,120,VehicleType.Car,1600);
            Console.WriteLine($"Model:{car.ModelNo},\n  yearmake:{car.YearMake} \n numberofseat: {car.NumberOfSeat} \n milage{car.MileageKmpl} \n  VehicleType type: {car.type} \t enginecapacitycc:{car.EngineCapacityCc} ");
            //Motor cycle design
            Console.WriteLine("===========Motorcycle Design===================");
            MotorCycle<string> m = new MotorCycle<string>("Hero honda-S20", 2000, 3, 4, 120, VehicleType.MotorCycle, 150,12);
            Console.WriteLine($"Model:{m.NumberOfDoor}");
            Console.ReadLine();


        }
    }
}
