﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle_Generic_Approach
{
    public class Car<S>:Twowheleer<S>
    {
        public Car()
        { }
        public Car(string modelno, int yearmake, int numberofseat, int numberofgear, int milage, VehicleType type, int enginecapacitycc)
        {
            this.ModelNo = modelno;
            this.YearMake = yearmake;
            this.NumberOfSeat = numberofseat;
            this.NumberOfGear = numberofgear;
            this.MileageKmpl = milage;
            this.type = type;
            this.EngineCapacityCc = enginecapacitycc;
        }
        public int NumberOfDoor { get; set; }
        public override void Start()
        {
            Console.WriteLine("car Start Engine");
        }
        public override void RearBreak()
        {
            Console.WriteLine("car RearBreak");
        }
        public override void FrontBreak()
        {
            Console.WriteLine("car FrontBreak");
        }
    }
}

