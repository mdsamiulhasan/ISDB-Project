﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Mutlitasking
{
    public class Program
    {
       public static async Task Main(string[] args)
        {
            await Task.Run(() => Console.WriteLine("CreateFactoryTask"));
            await Task.Run(() => Console.WriteLine("CreateUsingTaskAction"));
            await Task.Run(()=>Console.WriteLine("CreateUsingTaskDelegate"));
            await Task.Run(()=> Console.WriteLine("CreateUsingTaskLamdaExpression"));
            
            await Task.Run(() => Console.WriteLine("CreateUsingTaskAsync"));
         

            //user input
            Console.WriteLine("Enter FirstNumber: ");
            int firstNumber = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter secondNumber: ");
            int secondNumber= int.Parse(Console.ReadLine());
            int result = firstNumber + secondNumber;
            Console.WriteLine("Result is: "+ result);
            Console.ReadLine();

            

        }


        private static Task CreateFactoryTask()
        {
            return Task.Factory.StartNew(() =>
            {
                Console.WriteLine("CreateFactoryTask");
            });
        }
        private static Task CreateUsingTaskAction()
        {
            return Task.Run(() =>
            {
                Console.WriteLine("CreateUsingTaskAction");
            });
        }
        private static Task CreateUsingTaskDelegate()
        {
            return Task.Run(() =>
            {
                Console.WriteLine("CreateUsingTaskDelegate");
            });
        }
        private static Task CreateUsingTaskLamdaExpression()
        {
            return Task.Run(() =>
            {
                Console.WriteLine("CreateUsingTaskLamdaExpression");
            });
        }
        private static async Task CreateUsingTaskAsync()
        {
            await Task.Run(() =>
            {
                Console.WriteLine("CreateUsingTaskAsync");
            });
        }
        private static int add(int num1, int num2)
        {
            return num1 + num2;
        }
        private static Task<int> SolveMath(int firstNumber, int secondNumber)
        {
            return Task.Run(() =>
            {
                return add(firstNumber, secondNumber);
            });
        }
        //private static Task createfactoryactionTask()
        //{
        //    return Task.Factory.StartNew(() => { Console.WriteLine("createfactoryactionTask"); });
        //}
        //private static Task createusingActionTask()
        //{
        //    return Task.Run(() => { Console.WriteLine("createusingActionTask"); });

        //}
        //private static Task createusingLamdaTask()
        //{
        //    return Task.Run(() => { Console.WriteLine("createusingLamdaTask"); });

        //}
        //private static async Task createusingasync()
        //{
        //    await Task.Run(() => { Console.WriteLine("createusingLamdaTask"); });

        //}
        //private static int add(int num1, int num2)
        //{
        //    return num1 + num2;
        //}
        //private static Task<int> Solvemath(int firstNumber,int secondNumber)
        //{
        //    return Task.Run(() => {
        //        return add(firstNumber, secondNumber);
        //    });
        //}
    }
}
