-----Project Name: School Management System Project
---create database

CREATE DATABASE School
ON PRIMARY
(
    NAME = School_Data,
    FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\School_Data.mdf',
    SIZE = 25MB,
    MAXSIZE = 50MB,
    FILEGROWTH = 5%
)
LOG ON
(
    NAME = Log_School_Data,
    FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\Log_School_Data.ldf',
    SIZE = 2MB,
    MAXSIZE = 25MB,
    FILEGROWTH = 1%
)
GO
--USE DATABASE
Use School
Go

---Create all table
---crate student table
CREATE TABLE Student (
    StudentID INT PRIMARY KEY IDENTITY(1,1),
    StudentName VARCHAR(100),
    DateOfBirth DATE,
    Gender CHAR(1)
)


---create teacher table
CREATE TABLE Teacher (
    TeacherID INT PRIMARY KEY IDENTITY(1,1),
    TeacherName VARCHAR(100),
    SubjectName VARCHAR(100)
)


---course table
CREATE TABLE Course (
    CourseID INT PRIMARY KEY IDENTITY(1,1),
    CourseName VARCHAR(100),
    TeacherID INT,
    CONSTRAINT FK_CourseTeacher FOREIGN KEY (TeacherID) REFERENCES Teacher(TeacherID)
)
-----Enrollment table
CREATE TABLE Enrollment (
    StudentID INT,
    CourseID INT,
    EnrollmentDate DATE,
    PRIMARY KEY (StudentID, CourseID),
    CONSTRAINT FK_EnrollmentStudent FOREIGN KEY (StudentID) REFERENCES Student(StudentID),
    CONSTRAINT FK_EnrollmentCourse FOREIGN KEY (CourseID) REFERENCES Course(CourseID)
)
----CREATE TABLE GRADE
    CREATE TABLE Grade (
    GradeID INT PRIMARY KEY IDENTITY(1,1),
    StudentID INT,
    CourseID INT,
    Grades CHAR(2),
    CONSTRAINT FK_GradeStudent FOREIGN KEY (StudentID) REFERENCES Student(StudentID),
    CONSTRAINT FK_GradeCourse FOREIGN KEY (CourseID) REFERENCES Course(CourseID)
)
GO
-------
-- Drop Foreign Key Constraints if they exist
IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_GradeStudent')
    ALTER TABLE Grade DROP CONSTRAINT FK_GradeStudent;



-------------insert data into the table
-- Insert data
INSERT INTO Student (StudentName, DateOfBirth, Gender)
VALUES
('Abul', '2001-04-12', 'M'),
('Malek', '2002-07-23', 'F'),
('Khalek', '2000-11-01', 'M');
GO
-----insert data into teacer
INSERT INTO Teacher (TeacherName, SubjectName)
VALUES
('Md Sajedul Islam', 'Data_Entry'),
('Md.Aliul Islam', 'SQL'),
('Mst.Umme Aymun nesa', 'C#');
GO
--insert data into Course
INSERT INTO Course (CourseName, TeacherID)
VALUES
('Computer_Fundamental', 1),
('ASP.net', 2),
('css', 3);
GO

--insert data  into Enrollment
INSERT INTO Enrollment (StudentID, CourseID, EnrollmentDate)
VALUES
(1, 1, '2024-07-15'),
(2, 2, '2024-07-16'),
(3, 3, '2024-07-17');
GO
------grade table
INSERT INTO Grade (StudentID, CourseID, Grades)
VALUES
(1, 1, 'A'),
(2, 2, 'B'),
(3, 3, 'C');
GO

-- Query to verify data
SELECT * FROM Student
SELECT * FROM Teacher
SELECT * FROM Course
SELECT * FROM Enrollment
SELECT * FROM Grade
GO


-----STEP 2: USE Stored Procedures with Transaction
CREATE PROC Enroll

    @StudentID INT,
    @CourseID INT
AS
BEGIN
BEGIN Transaction;
---check if the students are already enrolled
IF NOT EXISTS
(
Select 1 from Enrollment Where StudentID=@StudentID And CourseID=@CourseID
)
BEGIN
---ENROLL THE STUDENTS
INSERT INTO Enrollment(StudentID, CourseID, EnrollmentDate)
VALUES(@StudentID,@CourseID,GETDATE())
COMMIT TRANSACTION;
PRINT 'Students enrolled successfully';
END
ELSE
BEGIN 

ROLLBACK Transaction
  PRINT 'Student is already enrolled in this course.';
  END
  END

GO
------READ 
  SELECT * FROM Enrollment
  GO

  --STEP--4: Trigger

 CREATE Trigger GradeTrigger
 On Enrollment
 AFTER
 INSERT
 AS 
 BEGIN
 INSERT INTO Grade(StudentID, CourseID, Grades)
 SELECT StudentID,CourseID,'N/A'
 FROM Grade;

 END

 GO
----------STEP: 4 : USING FUNCTION
CREATE FUNCTION AverageGrade(@StudentID INT)
RETURNS FLOAT
BEGIN
DECLARE @AverageGrade FLOAT
SELECT @AverageGrade=AVG(CASE

        WHEN   Grades = 'A' THEN 4.0
        WHEN Grades = 'B' THEN 3.0
        WHEN Grades = 'C' THEN 2.0
        WHEN Grades= 'D' THEN 1.0
		else 0.0 end
)
FROM Grade

    WHERE StudentID = @StudentID;

    RETURN @AverageGrade;
END;
GO

---STEP: 5 :VIEW

CREATE VIEW CREATEVIEW
AS
SELECT 
    s.StudentName,
    c.CourseName,
    e.EnrollmentDate,
    g.Grades
FROM 
    Student s
INNER JOIN 
    Enrollment e ON s.StudentID = e.StudentID
INNER JOIN 
    Course c ON e.CourseID = c.CourseID
INNER JOIN 
    Grade g ON e.StudentID = g.StudentID AND e.CourseID = g.CourseID;
GO

---------------STEP: 6 =INDEXING

CREATE INDEX Enrollment_StudentID_CourseID
ON Enrollment (StudentID, CourseID);
GO

--------STEP: 7 =SAMPLE QUERY
SELECT 
    s.StudentName,
    dbo.AverageGrade(s.StudentID) AS AverageGrade
FROM 
    Student s;


	------MOREOVER

	SELECT 
    s.StudentName,
    c.CourseName,
    e.EnrollmentDate,
    g.Grades
FROM 
  Student s,Course c,Enrollment e,Grade g
WHERE 
    s.StudentID = 2;


	-------------------The END OF THE PROJECT --------------
























